package in.arjsna.mapsalarm.mvpbase;

public interface IMVPView {
}
