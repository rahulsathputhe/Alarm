package in.arjsna.mapsalarm.global;

import android.location.Location;

public interface AppLocationListener {
  void onLocationAvailable(Location location);
}
