# LocationAware
Set alarms for location in map

<a href='https://play.google.com/store/apps/details?id=in.arjsna.mapsalarm' target='_blank'><img height='50' style='border:0px;height:50px;' src='https://cdn.rawgit.com/Arjun-sna/Arjun-sna.github.io/f8228c83/raw/GooglePlay.png' border='0' alt='GooglePlay Link' /></a>

<img src="https://arjun-sna.github.io/raw/locationaware_1.png" width="250" />  <img src="https://arjun-sna.github.io/raw/locationaware_2.png" width="250" />  <img src="https://arjun-sna.github.io/raw/locationaware_3.png" width="250" />

